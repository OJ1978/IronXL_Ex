﻿using IronXL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IronXL_Ex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WorkBook workbook = WorkBook.LoadCSV("Students.csv", fileFormat: ExcelFileFormat.XLSX, ListDelimiter: ",");
            WorkSheet ws = workbook.DefaultWorkSheet;
            workbook.SaveAs("Csv_To_Excel.xlsx");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataTable table = new DataTable();
            DataRow row;

            table.Columns.Add("ID", typeof(string));
            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("Course", typeof(string));

            row = table.NewRow();
            row["ID"] = "1";
            row["Name"] = "John";
            row["Course"] = "Excel";
            table.Rows.Add(row);

            row = table.NewRow();
            row["ID"] = "2";
            row["Name"] = "Pete";
            row["Course"] = "Word";
            table.Rows.Add(row);

            row = table.NewRow();
            row["ID"] = "3";
            row["Name"] = "Tom";
            row["Course"] = "Business";
            table.Rows.Add(row);

            row = table.NewRow();
            row["ID"] = "4";
            row["Name"] = "Susan";
            row["Course"] = "Secretarial";
            table.Rows.Add(row);

            row = table.NewRow();
            row["ID"] = "5";
            row["Name"] = "Monica";
            row["Course"] = "Graphics";
            table.Rows.Add(row);

            WorkBook wb = WorkBook.Create(ExcelFileFormat.XLSX);
            wb.Metadata.Author = "OJ";
            WorkSheet ws = wb.DefaultWorkSheet;
            int rowCount = 1;
            foreach (DataRow currow in table.Rows)
            {
                ws["A" + (rowCount)].Value = currow[0].ToString();
                ws["B" + (rowCount)].Value = currow[1].ToString();
                ws["C" + (rowCount)].Value = currow[2].ToString();

                rowCount++;
            }
            wb.SaveAsCsv("Students_2.csv", ","); 

        }
    }
}
